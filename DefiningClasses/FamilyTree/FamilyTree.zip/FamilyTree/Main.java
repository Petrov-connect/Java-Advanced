package DefiningClasses.FamilyTree;
//created by J.M.

import java.util.*;
import static DefiningClasses.FamilyTree.Person.findPerson;
import static DefiningClasses.FamilyTree.Person.getFamilyTreeFor;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String personId = scan.nextLine();
        List<Person> people = new ArrayList<>();
        Map<String, List<String>> parentChildren = new LinkedHashMap<>();
        String input;

        while (!"End".equals(input = scan.nextLine())) {
            if (input.contains(" - ")) {
                String[] tokens = input.split(" - ");
                String parentId = tokens[0];
                String childId = tokens[1];
                parentChildren.putIfAbsent(parentId, new ArrayList<>());
                parentChildren.get(parentId).add(childId);
            } else {
                String[] tokens = input.split("\\s+");
                String name = tokens[0] + " " + tokens[1];
                String birthDate = tokens[2];
                people.add(new Person(name, birthDate));
            }
        }

        parentChildren.forEach((parentId, children) -> {
            Person parent = findPerson(people, parentId);

            children.stream()
                    .map(childId -> findPerson(people, childId))
                    .forEach(parent::addChild);
        });

        Person forPerson = findPerson(people, personId);

        System.out.println(getFamilyTreeFor(forPerson));
    }
}

